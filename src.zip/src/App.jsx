import { useEffect, useState } from 'react'
import './App.css'
import Header from '@/components/Header';
import List from '@/components/List';

function App({setTitle, setMessage}) {
  const [sections, setSections] = useState(() => {
    const saved = localStorage.getItem('sections');
    return saved ? JSON.parse(saved) : [];
  });

  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    localStorage.setItem('sections', JSON.stringify(sections));
  }, [sections]);

    const resetBoard = () => {
    setSections([]);
    setTitle("");
    setMessage("");
  };

  return (
    <div>
    <main className='min-h-screen w-full bg-zinc-300 dark:bg-zinc-800 transition-colors duration-500'>
    <Header resetBoard={resetBoard} searchTerm={searchTerm} setSearchTerm={setSearchTerm} />
    <List sections={sections} setSections={setSections} searchTerm={searchTerm} />
    </main>
    </div>
  )
}

export default App
